from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_cors import CORS
import hashlib
import boto3
import uuid
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)
app.secret_key = 'movie_magic_secret_key_2024'

# AWS Configuration (Use environment variables in production)
# For local development, these will use local data structures
USE_AWS = os.getenv('USE_AWS', 'False').lower() == 'true'

if USE_AWS:
    # AWS Services Setup
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    sns = boto3.client('sns', region_name='us-east-1')
    
    # DynamoDB Tables
    users_table = dynamodb.Table('MovieMagic_Users')
    bookings_table = dynamodb.Table('MovieMagic_Bookings')
    
    # SNS Configuration
    sns_topic_arn = 'arn:aws:sns:us-east-1:123456789012:MovieMagicBookings'
    
    # Email Configuration
    SMTP_SERVER = 'smtp.gmail.com'
    SMTP_PORT = 587
    SENDER_EMAIL = 'your_email@gmail.com'
    SENDER_PASSWORD = 'your_app_password'
else:
    # Local data storage for development
    users_data = {}
    bookings_data = {}

# Sample movie data
MOVIES_DATA = [
    {
        'id': 1,
        'title': 'Avengers: Endgame',
        'genre': 'Action, Adventure, Drama',
        'rating': '8.4',
        'duration': '181 min',
        'language': 'English',
        'image': 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg',
        'description': 'The ultimate superhero epic that brings together all Marvel heroes.',
        'theaters': [
            {'name': 'PVR Cinemas', 'location': 'Downtown Mall', 'times': ['10:00 AM', '1:30 PM', '5:00 PM', '8:30 PM'], 'price': 250},
            {'name': 'INOX Movies', 'location': 'City Center', 'times': ['11:00 AM', '2:30 PM', '6:00 PM', '9:30 PM'], 'price': 280},
            {'name': 'Cineplex Theater', 'location': 'Grand Plaza', 'times': ['10:30 AM', '2:00 PM', '5:30 PM', '9:00 PM'], 'price': 220}
        ]
    },
    {
        'id': 2,
        'title': 'The Dark Knight',
        'genre': 'Action, Crime, Drama',
        'rating': '9.0',
        'duration': '152 min',
        'language': 'English',
        'image': 'https://images.pexels.com/photos/7991748/pexels-photo-7991748.jpeg',
        'description': 'Batman faces his greatest challenge yet with the enigmatic Joker.',
        'theaters': [
            {'name': 'PVR Cinemas', 'location': 'Downtown Mall', 'times': ['11:00 AM', '2:30 PM', '6:00 PM', '9:30 PM'], 'price': 240},
            {'name': 'MovieMax', 'location': 'Star Mall', 'times': ['10:15 AM', '1:45 PM', '5:15 PM', '8:45 PM'], 'price': 200}
        ]
    },
    {
        'id': 3,
        'title': 'Interstellar',
        'genre': 'Adventure, Drama, Sci-Fi',
        'rating': '8.6',
        'duration': '169 min',
        'language': 'English',
        'image': 'https://images.pexels.com/photos/2183739/pexels-photo-2183739.jpeg',
        'description': 'A team of explorers travel through a wormhole in space.',
        'theaters': [
            {'name': 'INOX Movies', 'location': 'City Center', 'times': ['12:00 PM', '3:30 PM', '7:00 PM', '10:30 PM'], 'price': 300},
            {'name': 'Cineplex Theater', 'location': 'Grand Plaza', 'times': ['11:30 AM', '3:00 PM', '6:30 PM', '10:00 PM'], 'price': 260}
        ]
    }
]

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def send_booking_notification(user_email, booking_details):
    """Send booking confirmation email"""
    if USE_AWS:
        try:
            message = f"""
            Movie Booking Confirmation
            
            Booking ID: {booking_details['booking_id']}
            Movie: {booking_details['movie_title']}
            Theater: {booking_details['theater']}
            Date: {booking_details['date']}
            Time: {booking_details['time']}
            Seats: {booking_details['seats']}
            Total Amount: ₹{booking_details['total_amount']}
            
            Thank you for choosing Movie Magic!
            """
            
            sns.publish(
                TopicArn=sns_topic_arn,
                Message=message,
                Subject='Movie Booking Confirmation'
            )
            return True
        except Exception as e:
            print(f"SNS Error: {e}")
            return False
    else:
        # Local development - just print the notification
        print(f"Booking confirmation sent to {user_email}")
        print(f"Booking Details: {booking_details}")
        return True

# API Routes
@app.route('/api/movies')
def get_movies():
    """Get all movies"""
    return jsonify(MOVIES_DATA)

@app.route('/api/movies/<int:movie_id>')
def get_movie(movie_id):
    """Get specific movie details"""
    movie = next((m for m in MOVIES_DATA if m['id'] == movie_id), None)
    if movie:
        return jsonify(movie)
    return jsonify({'error': 'Movie not found'}), 404

@app.route('/api/register', methods=['POST'])
def register():
    """User registration"""
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')
    phone = data.get('phone')
    
    if not all([email, password, full_name, phone]):
        return jsonify({'error': 'All fields are required'}), 400
    
    if USE_AWS:
        try:
            # Check if user already exists
            response = users_table.get_item(Key={'Email': email})
            if 'Item' in response:
                return jsonify({'error': 'User already exists'}), 400
            
            # Create new user
            users_table.put_item(Item={
                'Email': email,
                'Password': hash_password(password),
                'FullName': full_name,
                'Phone': phone,
                'LoginCount': 0,
                'CreatedAt': datetime.now().isoformat()
            })
        except Exception as e:
            return jsonify({'error': 'Registration failed'}), 500
    else:
        # Local storage
        if email in users_data:
            return jsonify({'error': 'User already exists'}), 400
        
        users_data[email] = {
            'password': hash_password(password),
            'full_name': full_name,
            'phone': phone,
            'login_count': 0,
            'created_at': datetime.now().isoformat()
        }
    
    return jsonify({'message': 'Registration successful'})

@app.route('/api/login', methods=['POST'])
def login():
    """User login"""
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    if not all([email, password]):
        return jsonify({'error': 'Email and password required'}), 400
    
    hashed_password = hash_password(password)
    
    if USE_AWS:
        try:
            response = users_table.get_item(Key={'Email': email})
            if 'Item' not in response:
                return jsonify({'error': 'Invalid credentials'}), 401
            
            user = response['Item']
            if user['Password'] != hashed_password:
                return jsonify({'error': 'Invalid credentials'}), 401
            
            # Update login count
            users_table.update_item(
                Key={'Email': email},
                UpdateExpression='SET LoginCount = LoginCount + :val',
                ExpressionAttributeValues={':val': 1}
            )
            
            session['user_email'] = email
            session['user_name'] = user['FullName']
            
            return jsonify({
                'message': 'Login successful',
                'user': {
                    'email': email,
                    'name': user['FullName']
                }
            })
        except Exception as e:
            return jsonify({'error': 'Login failed'}), 500
    else:
        # Local storage
        if email not in users_data:
            return jsonify({'error': 'Invalid credentials'}), 401
        
        user = users_data[email]
        if user['password'] != hashed_password:
            return jsonify({'error': 'Invalid credentials'}), 401
        
        user['login_count'] += 1
        session['user_email'] = email
        session['user_name'] = user['full_name']
        
        return jsonify({
            'message': 'Login successful',
            'user': {
                'email': email,
                'name': user['full_name']
            }
        })

@app.route('/api/logout', methods=['POST'])
def logout():
    """User logout"""
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

@app.route('/api/book-ticket', methods=['POST'])
def book_ticket():
    """Book movie ticket"""
    if 'user_email' not in session:
        return jsonify({'error': 'Please login first'}), 401
    
    data = request.get_json()
    movie_id = data.get('movie_id')
    theater_name = data.get('theater_name')
    theater_location = data.get('theater_location')
    show_time = data.get('show_time')
    show_date = data.get('show_date')
    selected_seats = data.get('selected_seats')
    ticket_price = data.get('ticket_price')
    
    if not all([movie_id, theater_name, show_time, show_date, selected_seats, ticket_price]):
        return jsonify({'error': 'All booking details are required'}), 400
    
    # Find movie details
    movie = next((m for m in MOVIES_DATA if m['id'] == movie_id), None)
    if not movie:
        return jsonify({'error': 'Movie not found'}), 404
    
    # Generate booking ID
    booking_id = str(uuid.uuid4())[:8].upper()
    total_amount = len(selected_seats) * ticket_price
    
    booking_details = {
        'booking_id': booking_id,
        'user_email': session['user_email'],
        'movie_id': movie_id,
        'movie_title': movie['title'],
        'theater': theater_name,
        'theater_location': theater_location,
        'show_time': show_time,
        'show_date': show_date,
        'selected_seats': selected_seats,
        'ticket_price': ticket_price,
        'total_amount': total_amount,
        'booking_date': datetime.now().isoformat(),
        'status': 'confirmed'
    }
    
    if USE_AWS:
        try:
            # Store booking in DynamoDB
            bookings_table.put_item(Item={
                'Booking_id': booking_id,
                'UserEmail': session['user_email'],
                'MovieId': movie_id,
                'MovieTitle': movie['title'],
                'Theater': theater_name,
                'TheaterLocation': theater_location,
                'ShowTime': show_time,
                'ShowDate': show_date,
                'SelectedSeats': selected_seats,
                'TicketPrice': ticket_price,
                'TotalAmount': total_amount,
                'BookingDate': datetime.now().isoformat(),
                'Status': 'confirmed'
            })
        except Exception as e:
            return jsonify({'error': 'Booking failed'}), 500
    else:
        # Local storage
        bookings_data[booking_id] = booking_details
    
    # Send notification
    notification_details = {
        'booking_id': booking_id,
        'movie_title': movie['title'],
        'theater': f"{theater_name}, {theater_location}",
        'date': show_date,
        'time': show_time,
        'seats': ', '.join(selected_seats),
        'total_amount': total_amount
    }
    
    send_booking_notification(session['user_email'], notification_details)
    
    return jsonify({
        'message': 'Booking successful',
        'booking_details': booking_details
    })

@app.route('/api/user-bookings')
def get_user_bookings():
    """Get user's booking history"""
    if 'user_email' not in session:
        return jsonify({'error': 'Please login first'}), 401
    
    user_email = session['user_email']
    
    if USE_AWS:
        try:
            response = bookings_table.scan(
                FilterExpression='UserEmail = :email',
                ExpressionAttributeValues={':email': user_email}
            )
            bookings = response.get('Items', [])
        except Exception as e:
            return jsonify({'error': 'Failed to fetch bookings'}), 500
    else:
        # Local storage
        bookings = [booking for booking in bookings_data.values() 
                   if booking['user_email'] == user_email]
    
    return jsonify(bookings)

@app.route('/api/check-session')
def check_session():
    """Check if user is logged in"""
    if 'user_email' in session:
        return jsonify({
            'logged_in': True,
            'user': {
                'email': session['user_email'],
                'name': session['user_name']
            }
        })
    return jsonify({'logged_in': False})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)