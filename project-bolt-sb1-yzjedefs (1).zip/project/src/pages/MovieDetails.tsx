import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Clock, MapPin, Calendar, Ticket } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Movie {
  id: number;
  title: string;
  genre: string;
  rating: string;
  duration: string;
  language: string;
  image: string;
  description: string;
  theaters: {
    name: string;
    location: string;
    times: string[];
    price: number;
  }[];
}

const MovieDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchMovie(parseInt(id));
    }
  }, [id]);

  const fetchMovie = async (movieId: number) => {
    try {
      const response = await fetch(`/api/movies/${movieId}`);
      const data = await response.json();
      setMovie(data);
    } catch (error) {
      console.error('Failed to fetch movie:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">Loading movie details...</div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">Movie not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Movie Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="grid lg:grid-cols-2 gap-12 mb-16"
        >
          <div className="relative">
            <img
              src={movie.image}
              alt={movie.title}
              className="w-full h-96 lg:h-full object-cover rounded-2xl shadow-2xl"
            />
            <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-full px-4 py-2 flex items-center">
              <Star className="h-5 w-5 text-yellow-400 mr-2" />
              <span className="text-white font-semibold">{movie.rating}</span>
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              {movie.title}
            </h1>
            <p className="text-purple-400 text-lg mb-4">{movie.genre}</p>
            
            <div className="flex flex-wrap gap-6 mb-6 text-gray-300">
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <span>{movie.duration}</span>
              </div>
              <div className="flex items-center">
                <span className="mr-2">🗣️</span>
                <span>{movie.language}</span>
              </div>
            </div>

            <p className="text-gray-300 text-lg leading-relaxed mb-8">
              {movie.description}
            </p>

            {!user && (
              <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4 mb-6">
                <p className="text-yellow-200">
                  Please <Link to="/login" className="text-yellow-300 font-semibold hover:underline">login</Link> to book tickets
                </p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Theaters & Showtimes */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center">
            <Ticket className="h-8 w-8 mr-3 text-purple-400" />
            Book Your Tickets
          </h2>

          <div className="space-y-6">
            {movie.theaters.map((theater, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
                  <div className="mb-4 lg:mb-0">
                    <h3 className="text-xl font-bold text-white mb-2">{theater.name}</h3>
                    <div className="flex items-center text-gray-300">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span>{theater.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-purple-400">₹{theater.price}</span>
                    <p className="text-gray-400 text-sm">per ticket</p>
                  </div>
                </div>

                <div className="flex items-center mb-4 text-gray-300">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Today, {new Date().toLocaleDateString()}</span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {theater.times.map((time, timeIndex) => (
                    <Link
                      key={timeIndex}
                      to={user ? `/booking/${movie.id}?theater=${encodeURIComponent(theater.name)}&location=${encodeURIComponent(theater.location)}&time=${encodeURIComponent(time)}&price=${theater.price}` : '/login'}
                      className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-4 rounded-lg text-center font-semibold hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-105"
                    >
                      {time}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default MovieDetails;