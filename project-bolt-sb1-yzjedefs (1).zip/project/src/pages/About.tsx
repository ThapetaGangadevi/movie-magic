import React from 'react';
import { motion } from 'framer-motion';
import { Film, Star, Users, Award, Shield, Clock } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: <Film className="h-8 w-8 text-purple-400" />,
      title: 'Latest Movies',
      description: 'Access to the newest blockbusters and indie films from around the world'
    },
    {
      icon: <Star className="h-8 w-8 text-purple-400" />,
      title: 'Premium Experience',
      description: 'State-of-the-art theaters with cutting-edge sound and visual technology'
    },
    {
      icon: <Users className="h-8 w-8 text-purple-400" />,
      title: 'Community Driven',
      description: 'Join millions of movie lovers in our vibrant community'
    },
    {
      icon: <Award className="h-8 w-8 text-purple-400" />,
      title: 'Award Winning',
      description: 'Recognized for excellence in digital entertainment services'
    },
    {
      icon: <Shield className="h-8 w-8 text-purple-400" />,
      title: 'Secure Booking',
      description: 'Your data and payments are protected with industry-leading security'
    },
    {
      icon: <Clock className="h-8 w-8 text-purple-400" />,
      title: '24/7 Support',
      description: 'Round-the-clock customer support for all your booking needs'
    }
  ];

  const stats = [
    { number: '1M+', label: 'Happy Customers' },
    { number: '500+', label: 'Partner Theaters' },
    { number: '50+', label: 'Cities Covered' },
    { number: '99.9%', label: 'Uptime' }
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            About <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Movie Magic</span>
          </h1>
          <p className="text-gray-300 text-lg md:text-xl max-w-4xl mx-auto leading-relaxed">
            We're revolutionizing the movie booking experience with cutting-edge technology, 
            seamless user interfaces, and a passion for bringing the magic of cinema to everyone, everywhere.
          </p>
        </motion.div>

        {/* Mission Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-8 md:p-12 border border-white/20 mb-16"
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Mission</h2>
            <p className="text-gray-300 text-lg max-w-3xl mx-auto">
              To make movie booking effortless, enjoyable, and accessible to everyone while supporting 
              theaters and filmmakers in creating unforgettable cinematic experiences.
            </p>
          </div>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-purple-400 mb-2">
                {stat.number}
              </div>
              <div className="text-gray-300">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Features Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
            Why Choose Movie Magic?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-600/20 rounded-full mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Technology Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 rounded-2xl p-8 md:p-12 border border-white/20 mb-16"
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Powered by Innovation</h2>
            <p className="text-gray-300 text-lg max-w-3xl mx-auto">
              Built with modern cloud technology including AWS services, real-time notifications, 
              and scalable infrastructure to handle millions of bookings seamlessly.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-2">Cloud-Native</h3>
              <p className="text-gray-300 text-sm">Deployed on AWS with auto-scaling capabilities</p>
            </div>
            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-2">Real-Time</h3>
              <p className="text-gray-300 text-sm">Instant notifications and live seat updates</p>
            </div>
            <div className="bg-white/5 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-2">Secure</h3>
              <p className="text-gray-300 text-sm">Enterprise-grade security for all transactions</p>
            </div>
          </div>
        </motion.div>

        {/* Team Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Built with ❤️ for Movie Lovers
          </h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-8">
            Our passionate team of developers, designers, and movie enthusiasts work tirelessly 
            to bring you the best movie booking experience possible.
          </p>
          <a
            href="/contact"
            className="inline-block bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-xl font-semibold hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-105"
          >
            Get In Touch
          </a>
        </motion.div>
      </div>
    </div>
  );
};

export default About;