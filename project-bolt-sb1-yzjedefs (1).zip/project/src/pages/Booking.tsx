import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, Clock, MapPin, CreditCard } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Movie {
  id: number;
  title: string;
  image: string;
}

const Booking = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [movie, setMovie] = useState<Movie | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [showDate, setShowDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);

  const theater = searchParams.get('theater') || '';
  const location = searchParams.get('location') || '';
  const time = searchParams.get('time') || '';
  const price = parseInt(searchParams.get('price') || '0');

  useEffect(() => {
    if (id) {
      fetchMovie(parseInt(id));
    }
  }, [id]);

  const fetchMovie = async (movieId: number) => {
    try {
      const response = await fetch(`/api/movies/${movieId}`);
      const data = await response.json();
      setMovie(data);
    } catch (error) {
      console.error('Failed to fetch movie:', error);
    }
  };

  const generateSeats = () => {
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const seatsPerRow = 12;
    const seats = [];
    
    for (const row of rows) {
      for (let i = 1; i <= seatsPerRow; i++) {
        seats.push(`${row}${i}`);
      }
    }
    
    return seats;
  };

  const seats = generateSeats();
  const unavailableSeats = ['A5', 'A6', 'B3', 'C7', 'C8', 'D10', 'E2', 'F5'];

  const handleSeatClick = (seat: string) => {
    if (unavailableSeats.includes(seat)) return;
    
    if (selectedSeats.includes(seat)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seat));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  const getSeatClass = (seat: string) => {
    if (unavailableSeats.includes(seat)) {
      return 'bg-red-500 cursor-not-allowed';
    }
    if (selectedSeats.includes(seat)) {
      return 'bg-purple-600 text-white';
    }
    return 'bg-white/20 hover:bg-purple-400 cursor-pointer';
  };

  const handleBooking = async () => {
    if (selectedSeats.length === 0) {
      alert('Please select at least one seat');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/book-ticket', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          movie_id: parseInt(id!),
          theater_name: theater,
          theater_location: location,
          show_time: time,
          show_date: showDate,
          selected_seats: selectedSeats,
          ticket_price: price
        }),
      });

      const data = await response.json();
      
      if (response.ok) {
        navigate('/booking-confirmation', { 
          state: { bookingDetails: data.booking_details } 
        });
      } else {
        alert(data.error || 'Booking failed');
      }
    } catch (error) {
      console.error('Booking failed:', error);
      alert('Booking failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!movie) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  const totalAmount = selectedSeats.length * price;

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl font-bold text-white mb-8 text-center">Book Your Seats</h1>
          
          {/* Booking Details */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/20">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-center space-x-4">
                <img
                  src={movie.image}
                  alt={movie.title}
                  className="w-20 h-28 object-cover rounded-lg"
                />
                <div>
                  <h2 className="text-xl font-bold text-white">{movie.title}</h2>
                  <p className="text-gray-300">{theater}</p>
                  <div className="flex items-center text-gray-400 mt-1">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="text-sm">{location}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center text-gray-300">
                  <Calendar className="h-5 w-5 mr-3" />
                  <input
                    type="date"
                    value={showDate}
                    onChange={(e) => setShowDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="bg-white/5 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div className="flex items-center text-gray-300">
                  <Clock className="h-5 w-5 mr-3" />
                  <span>{time}</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <CreditCard className="h-5 w-5 mr-3" />
                  <span>₹{price} per ticket</span>
                </div>
              </div>
            </div>
          </div>

          {/* Seat Selection */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 mb-8 border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">Select Your Seats</h3>
            
            {/* Screen */}
            <div className="text-center mb-8">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full max-w-md mx-auto mb-2"></div>
              <p className="text-gray-400 text-sm">SCREEN</p>
            </div>

            {/* Seats Grid */}
            <div className="max-w-4xl mx-auto">
              {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(row => (
                <div key={row} className="flex justify-center items-center mb-3">
                  <span className="text-white font-semibold w-8 text-center">{row}</span>
                  <div className="grid grid-cols-12 gap-2 mx-4">
                    {Array.from({ length: 12 }, (_, i) => {
                      const seat = `${row}${i + 1}`;
                      return (
                        <button
                          key={seat}
                          onClick={() => handleSeatClick(seat)}
                          className={`w-8 h-8 rounded text-xs font-semibold transition-all ${getSeatClass(seat)}`}
                          disabled={unavailableSeats.includes(seat)}
                        >
                          {i + 1}
                        </button>
                      );
                    })}
                  </div>
                  <span className="text-white font-semibold w-8 text-center">{row}</span>
                </div>
              ))}
            </div>

            {/* Legend */}
            <div className="flex justify-center space-x-6 mt-8 text-sm">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-white/20 rounded mr-2"></div>
                <span className="text-gray-300">Available</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-purple-600 rounded mr-2"></div>
                <span className="text-gray-300">Selected</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-500 rounded mr-2"></div>
                <span className="text-gray-300">Unavailable</span>
              </div>
            </div>
          </div>

          {/* Booking Summary */}
          {selectedSeats.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
            >
              <h3 className="text-xl font-bold text-white mb-4">Booking Summary</h3>
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-300">Selected Seats:</span>
                <span className="text-white font-semibold">{selectedSeats.join(', ')}</span>
              </div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-300">Number of Tickets:</span>
                <span className="text-white font-semibold">{selectedSeats.length}</span>
              </div>
              <div className="flex justify-between items-center mb-6">
                <span className="text-gray-300">Total Amount:</span>
                <span className="text-2xl font-bold text-purple-400">₹{totalAmount}</span>
              </div>
              
              <button
                onClick={handleBooking}
                disabled={loading}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Processing...' : `Pay ₹${totalAmount} & Book Tickets`}
              </button>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Booking;