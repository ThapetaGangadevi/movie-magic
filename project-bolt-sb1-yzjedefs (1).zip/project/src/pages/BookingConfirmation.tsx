import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Download, Calendar, Clock, MapPin, Ticket, User, Mail } from 'lucide-react';

const BookingConfirmation = () => {
  const location = useLocation();
  const bookingDetails = location.state?.bookingDetails;

  if (!bookingDetails) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">No booking details found</p>
          <Link
            to="/movies"
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all"
          >
            Browse Movies
          </Link>
        </div>
      </div>
    );
  }

  const handleDownloadTicket = () => {
    const ticketContent = `
MOVIE MAGIC - TICKET
====================
Booking ID: ${bookingDetails.booking_id}
Movie: ${bookingDetails.movie_title}
Theater: ${bookingDetails.theater}
Location: ${bookingDetails.theater_location}
Date: ${bookingDetails.show_date}
Time: ${bookingDetails.show_time}
Seats: ${bookingDetails.selected_seats.join(', ')}
Total Amount: ₹${bookingDetails.total_amount}
====================
Present this ticket at the theater entrance.
    `;

    const blob = new Blob([ticketContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ticket-${bookingDetails.booking_id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-500 rounded-full mb-6">
            <CheckCircle className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Booking Confirmed!
          </h1>
          <p className="text-gray-300 text-lg">
            Your movie tickets have been successfully booked. A confirmation email has been sent to you.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 mb-8"
        >
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Booking Details</h2>
            <p className="text-purple-400 text-lg font-semibold">
              Booking ID: {bookingDetails.booking_id}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <Ticket className="h-6 w-6 text-purple-400 mt-1" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Movie</h3>
                  <p className="text-gray-300">{bookingDetails.movie_title}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <MapPin className="h-6 w-6 text-purple-400 mt-1" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Theater</h3>
                  <p className="text-gray-300">{bookingDetails.theater}</p>
                  <p className="text-gray-400 text-sm">{bookingDetails.theater_location}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Calendar className="h-6 w-6 text-purple-400 mt-1" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Show Date</h3>
                  <p className="text-gray-300">{bookingDetails.show_date}</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <Clock className="h-6 w-6 text-purple-400 mt-1" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Show Time</h3>
                  <p className="text-gray-300">{bookingDetails.show_time}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <User className="h-6 w-6 text-purple-400 mt-1" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Seats</h3>
                  <p className="text-gray-300">{bookingDetails.selected_seats.join(', ')}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Mail className="h-6 w-6 text-purple-400 mt-1" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Total Amount</h3>
                  <p className="text-2xl font-bold text-purple-400">₹{bookingDetails.total_amount}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <button
            onClick={handleDownloadTicket}
            className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 transition-all flex items-center justify-center"
          >
            <Download className="h-5 w-5 mr-2" />
            Download Ticket
          </button>
          
          <Link
            to="/movies"
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all text-center"
          >
            Book More Tickets
          </Link>
          
          <Link
            to="/profile"
            className="border-2 border-white/30 text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition-all text-center"
          >
            View All Bookings
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="bg-blue-500/20 border border-blue-500/50 rounded-lg p-6 mt-8"
        >
          <h3 className="text-white font-semibold mb-2">Important Information</h3>
          <ul className="text-blue-200 text-sm space-y-1">
            <li>• Please arrive at the theater at least 30 minutes before the show time</li>
            <li>• Carry a valid ID proof along with your ticket</li>
            <li>• Outside food and beverages are not allowed</li>
            <li>• Check your email for the digital ticket copy</li>
          </ul>
        </motion.div>
      </div>
    </div>
  );
};

export default BookingConfirmation;